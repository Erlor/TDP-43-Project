The YeastNet.V3.txt file is downloaded from http://www.inetbio.org/yeastnet/


