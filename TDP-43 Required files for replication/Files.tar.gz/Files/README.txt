Each folder contains 10 files with data. 9 are the raw growth stats, that has been merged with their respective name. 
Each is named by it's date of creation and from which set it came. 
The 10th is the normalized values from each, used for sifting out candidates in the folder R/Sifting\ through\ candidates

The Extras folder contain Network data, aggregation data an the Gene list connecting each number to a name. 
